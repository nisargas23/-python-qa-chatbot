# Personal Python Q&A Chatbot — Streamlit App

A chat-style Streamlit app that answers Python programming questions from a
built-in knowledge base (exact match → fuzzy match → keyword overlap).

## Files
```
streamlit-python-qa/
├── app.py              # the Streamlit app + knowledge base
├── requirements.txt    # dependencies (just streamlit)
└── README.md           # this file
```

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
This opens the app at http://localhost:8501

## Deploy to Streamlit Community Cloud (free)
1. Push this folder to a **public GitHub repository** (Streamlit Cloud deploys
   straight from GitHub).
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click **"New app"**, pick your repo, branch, and set **Main file path**
   to `app.py`.
4. Click **Deploy**. Streamlit installs `requirements.txt` automatically and
   gives you a public URL like `https://your-app-name.streamlit.app`.

Any time you push new commits to the repo, the deployed app redeploys
automatically.

## Extending the knowledge base
Open `app.py` and add more entries to the `KNOWLEDGE_BASE` dictionary near
the top of the file — no other code changes needed.
